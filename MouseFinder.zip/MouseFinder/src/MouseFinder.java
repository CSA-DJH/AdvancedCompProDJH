/*
Daniel Herbowy
Chaparral Star Academy
MouseFinder v.1
Mr. Davis
1/14/2016
*/

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class MouseFinder extends Canvas implements MouseMotionListener
{
	private int x, y;
	
	public MouseFinder()
	{
		createWindow();
		setBackground(Color.BLACK);
		addMouseMotionListener(this);
	}
	
	private void createWindow()
	{
		JFrame window = new JFrame("mouse finder");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(1000,800);
		window.add(this);
		window.setVisible(true);
	}
	
	public void paint(Graphics gc)
	{
		gc.setColor(Color.YELLOW);
		gc.drawString(String.format("(%d,%d)",x,y),20,20);
		
		
		gc.setColor(Color.red);
                gc.drawLine(215, 222, 100, 100);
                gc.setColor(Color.red);
                gc.drawLine(615, 222, 500, 100);
                gc.setColor(Color.red);
                gc.drawLine(500, 100, 100, 100);
                gc.setColor(Color.red);
		gc.drawRect(215,222,400,400);
                gc.setColor(Color.red);
                gc.drawRect(100, 100, 400, 400);
                gc.setColor(Color.red);
                gc.drawLine(100, 500, 215, 622);
                gc.setColor(Color.red);
                gc.drawLine(500, 500, 615, 622);
	}
	
	public void mouseMoved(MouseEvent mouse)
	{
		x = mouse.getX(); 
		y = mouse.getY(); 
		repaint();    
	}
	
	public void mouseDragged(MouseEvent e)
	{
		
	}
	
	public static void main(String[] args)
	{
		new MouseFinder();
	}
}