import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class MouseFinder extends Canvas implements MouseMotionListener
{
	private int x, y;
	
	public MouseFinder()
	{
		createWindow();
		setBackground(Color.BLACK);
		addMouseMotionListener(this);
	}
	
	private void createWindow()
	{
		JFrame window = new JFrame("mouse finder");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(800,600);
		window.add(this);
		window.setVisible(true);
	}
	
	public void paint(Graphics gc)
	{
		gc.setColor(Color.YELLOW);
		gc.drawString(String.format("(%d,%d)",x,y),20,20);
		
		gc.setColor(Color.MAGENTA);
		gc.drawOval(68,72,350,280);
		gc.setColor(Color.CYAN);
		gc.drawOval(215,122,400,400);
	}
	
	public void mouseMoved(MouseEvent mouse)
	{
		x = mouse.getX(); // gets the mouse x coordinate
		y = mouse.getY(); // gets the mouse y coordinate
		repaint();    // redraws the screen to show updated x & y
	}
	
	public void mouseDragged(MouseEvent e)
	{
		// necessary for MouseMotionListener but unused here
	}
	
	public static void main(String[] args)
	{
		new MouseFinder();
	}
}